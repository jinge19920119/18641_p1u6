Project 1 - Unit 6    readme.txt

1.There are several several files in it. As usually, there are 1 class diagram,2 input files, one db_schema file for input to MySQL and output for every step. 

(In the mysql-connector-java-5.1.36 file, there is a Jar file that contains the library for JDBC.) It was my plan to add this file, however, it fails and can’t email so i delete it. Please remember to add one jdbc to run it.

2. class diagram.png is the class diagram of this unit. readFileProp.properties and readFileProp1.properties are two input files.

3. JdbcBuild class in jdbc package is used for connect with MySQL and communicate with it. There are several methods in it that are used for creating, updating and deleting. 

4. The outcome of the MySQL is served in outcome.txt.

5. All the comments and explanations of the project has been written in the code as comments.