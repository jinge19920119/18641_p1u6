package adapter;

public interface CreateAuto {
	public void BuildAuto(String fileName);
	public void printAuto(String modelName);
	

}
